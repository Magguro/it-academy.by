#!/bin/bash
docker build -t node1:31320/docker:1.0 .
docker push node1:31320/docker:1.0


